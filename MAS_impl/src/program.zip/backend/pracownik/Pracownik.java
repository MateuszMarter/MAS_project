package backend.pracownik;

import backend.Raport;
import backend.StatusZadania;
import backend.Zadanie;
import backend.Zaloga;
import util.Ext;
import util.IdGenerator;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public abstract class Pracownik extends Ext {
    private static float PENSJA_PODSTAWOWA = 3500f;

    private int id;
    private String imie;
    private String nazwisko;
    private Zaloga zaloga;

    private final List<Raport> raporty = new ArrayList<>();

    public Pracownik(String imie, String nazwisko, Zaloga zaloga) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.zaloga = zaloga;
        this.id = Integer.parseInt(IdGenerator.genId());
    }

    public abstract float obliczPensje();

    public void wykonajZadanie(Zadanie zadanie) {
        zadanie.setStatus(StatusZadania.ZREALIZOWANE);
    }

    public void wybierzZadanie(Zadanie zadanie, String nazwaZadania, LocalDateTime deadline) {
        new Raport(nazwaZadania, this, zadanie, deadline);
        zadanie.setStatus(StatusZadania.NIEZREALIZOWANE);
    }

    public void wyswietlZadania() {
        getRaporty().forEach(r -> System.out.println(r.getZadanie()));
    }

    public void porzucZadanie(Zadanie zadanie) {
        getRaporty().removeIf(r -> r.getZadanie() == zadanie);
    }

    public static float getPensjaPodstawowa() {
        return PENSJA_PODSTAWOWA;
    }

    public static void setPensjaPodstawowa(float pensjaPodstawowa) {
        PENSJA_PODSTAWOWA = pensjaPodstawowa;
    }

    public int getId() {
        return id;
    }

    public String getImie() {
        return imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public Zaloga getZaloga() {
        return zaloga;
    }

    public List<Raport> getRaporty() {
        return raporty;
    }
}
