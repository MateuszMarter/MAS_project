package backend;

import backend.pracownik.Pracownik;
import util.Ext;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Raport extends Ext {
    private static final List<Zadanie> zadania = new ArrayList<>();
    private String opis;
    private LocalDateTime deadline;

    private Pracownik pracownik;
    private Zadanie zadanie;

    public Raport(String nazwaZadania, Pracownik pracownik, Zadanie zadanie, LocalDateTime deadline) {

    }

    public void setNazwaZadania(String nazwaZadania) {

    }

    public void setZadnie(Zadanie noweZadanie) {
        this.zadanie = noweZadanie;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public void setDeadline(LocalDateTime deadline) {
        this.deadline = deadline;
    }

    public void setPracownik(Pracownik pracownik) {
        this.pracownik = pracownik;
    }

    public static void dodajZadanie(Zadanie zadanie) {
        zadania.add(zadanie);
    }

    public static void usunZadanie(Zadanie zadanie) {
        zadania.remove(zadanie);
    }

    public Zadanie getZadanie() {
        return this.zadanie;
    }
}
