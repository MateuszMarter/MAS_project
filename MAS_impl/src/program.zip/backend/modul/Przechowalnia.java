package backend.modul;

public class Przechowalnia extends ModulBazowy {
    public Przechowalnia(StatusModulu statusModulu) {
        super(statusModulu);
    }
}
