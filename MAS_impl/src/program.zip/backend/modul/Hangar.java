package backend.modul;

public class Hangar extends ModulBazowy {

    public Hangar(StatusModulu statusModulu) {
        super(statusModulu);
    }


}
