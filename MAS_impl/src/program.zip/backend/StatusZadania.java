package backend;

public enum StatusZadania {
    ZREALIZOWANE, NIEZREALIZOWANE, DOSTEPNE
}
