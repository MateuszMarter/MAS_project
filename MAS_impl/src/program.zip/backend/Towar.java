package backend;

import util.Ext;

public class Towar extends Ext {

}
