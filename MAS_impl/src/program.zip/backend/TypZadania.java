package backend;

public enum TypZadania {
    MECHANICZNE, GOSPODARCZE, OGOLNE
}
