package backend;

import util.Ext;

public class Zadanie extends Ext {
    private StatusZadania statusZadania;
    private TypZadania typZadania;

    public Zadanie(TypZadania typZadania) {
        this.typZadania = typZadania;
        this.statusZadania = StatusZadania.DOSTEPNE;
    }

    public void setStatus(StatusZadania statusZadania) {
        this.statusZadania = statusZadania;
    }
}
