package backend.pojazd;

import util.Ext;

public class Transport extends Ext {

}
