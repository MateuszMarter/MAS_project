package backend.pojazd;

import util.Ext;

public class Pojazd extends Ext {
}
