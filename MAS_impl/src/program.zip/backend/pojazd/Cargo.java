package backend.pojazd;

import util.Ext;

public class Cargo extends Ext {
}
