package backend.zadanie;

public enum StatusZadania {
    ZREALIZOWANE, NIEZREALIZOWANE, DOSTEPNE
}
