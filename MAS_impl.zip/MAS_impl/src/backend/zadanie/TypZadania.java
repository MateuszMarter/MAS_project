package backend.zadanie;

public enum TypZadania {
    MECHANICZNE, GOSPODARCZE, OGOLNE
}
