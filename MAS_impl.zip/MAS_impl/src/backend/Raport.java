package backend;

import backend.pracownik.Pracownik;
import backend.zadanie.StatusZadania;
import backend.zadanie.Zadanie;
import util.Ext;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Raport extends Ext {
    private static final List<Zadanie> zadania = new ArrayList<>(); //wymagane
    private String nazwaZadania; //wymagane
    private String opis; //opcjonalne
    private LocalDateTime deadline; //wymagane

    private Pracownik pracownik; //wymagane
    private Zadanie zadanie; //wymagane

    public Raport(String nazwaZadania, Pracownik pracownik, Zadanie zadanie, LocalDateTime deadline) {
        setNazwaZadania(nazwaZadania);
        setZadnie(zadanie);
        setOpis(null);
        setDeadline(deadline);
        setPracownik(pracownik);
    }

    public static List<Zadanie> getZadania() {
        return zadania;
    }

    public void setNazwaZadania(String nazwaZadania) {
        this.nazwaZadania = nazwaZadania;
    }

    public void setZadnie(Zadanie zadanie) {
        this.zadanie = zadanie;
        zadanie.setRaport(this);
        zadanie.setStatus(StatusZadania.NIEZREALIZOWANE);
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public void setDeadline(LocalDateTime deadline) {
        this.deadline = deadline;
    }

    public void setPracownik(Pracownik pracownik) {
        this.pracownik = pracownik;
        pracownik.addRaport(this);
    }

    public static void dodajZadanie(Zadanie zadanie) {
        zadania.add(zadanie);
    }

    public static void usunZadanie(Zadanie zadanie) {
        zadania.remove(zadanie);
    }

    public Zadanie getZadanie() {
        return this.zadanie;
    }


    public String getNazwaZadania() {
        return nazwaZadania;
    }

    public Pracownik getPracownik() {
        return pracownik;
    }


    public String getOpis() {
        return opis;
    }


    public List<Pracownik> getAllPracownicy() {
        List<Raport> raportyZadania = zadanie.getRaporty();
        List<Pracownik> wspolPracownicy = new ArrayList<>();

        for(Raport raport : raportyZadania) {
            wspolPracownicy.add(raport.getPracownik());
        }

        return wspolPracownicy;
    }

    @Override
    public String toString() {
        return "Raport{" +
                "nazwaZadania='" + nazwaZadania + '\'' +
                ", opis='" + opis + '\'' +
                ", deadline=" + deadline +
                ", pracownik=" + pracownik +
                ", zadanie=" + zadanie +
                '}';
    }

    public LocalDateTime getDeadline() {
        return deadline;
    }
}
