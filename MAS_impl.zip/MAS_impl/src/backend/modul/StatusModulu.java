package backend.modul;

public enum StatusModulu {
    OPERACYJNA, NIEOPERACUYJNA
}
