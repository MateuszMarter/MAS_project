package backend.modul;

public enum TypModulu {
    HANGAR, PRZECHOWALNIA
}
