package frontend;

import backend.pracownik.Dowodca;

import java.awt.*;

public class TasksWindow extends Component {
    public TasksWindow(Dowodca dowodca) {

    }
}
