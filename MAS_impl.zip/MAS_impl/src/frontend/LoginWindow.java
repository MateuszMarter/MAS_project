package frontend;

import javax.swing.*;

public class LoginWindow extends JFrame {
    public LoginWindow() {
        super("Login");

    }
}
