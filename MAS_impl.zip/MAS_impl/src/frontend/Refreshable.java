package frontend;

public interface Refreshable {
    void refresh();
}
